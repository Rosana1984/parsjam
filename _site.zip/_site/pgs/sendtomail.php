<?

$to = "info@pars-jam.com" ;
$header = $_REQUEST['mail'];
$subject = $_REQUEST['flsubject'] ;
$contents = "Name: " . $_REQUEST['name'] . "\n" . "Phone: " . $_REQUEST['phone'] . "\n" . "E-mail: " . $_REQUEST['mail'] . "\n" . "Content: " . $_REQUEST['content'] ;

mail($to, $subject, $contents, $header);

print("<HTML><BODY><CENTER>Your Request was successfully sent!");
print("</BODY></HTML>");

?>