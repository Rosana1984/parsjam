<html>
<head>
<title>Alborz Oil</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<body bgcolor="#cccccc"  background="images/gradient_texture.png" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<!-- Save for Web Slices (empty.psd) -->
<table id="Table_01" width="949"  border="0" cellpadding="0" cellspacing="0" align="center" background="">
	<tr>
		<td colspan="2" rowspan="3">
			<img src="images/index_01.jpg" width="23" height="121" alt=""></td>
		<td colspan="11">
			<img src="images/index_02.jpg" width="863" height="27" alt=""></td>
		<td colspan="3" rowspan="2">
			<img src="images/index_03.jpg" width="63" height="93" alt=""></td>
	</tr>
	<tr>
		<td rowspan="2">
			<img src="images/index_04.jpg" width="106" height="94" alt=""></td>
		<td colspan="10">
			<img src="images/index_05.jpg" width="757" height="66" alt=""></td>
	</tr>
	<tr>
		<td><a href="contact.php"><img src="images/_index_06.jpg" alt="" width="139" height="28" border="0"></a></td>
		<td>
			<img src="images/index_07.jpg" width="12" height="28" alt=""></td>
		<td colspan="2"><a href="online.php"><img src="images/index_08.jpg" alt="" width="167" height="28" border="0"></a></td>
		<td>
			<img src="images/index_09.jpg" width="11" height="28" alt=""></td>
		<td><a href="products.php"><img src="images/index_10.jpg" alt="" width="145" height="28" border="0"></a></td>
		<td>
			<img src="images/index_11.jpg" width="11" height="28" alt=""></td>
		<td><a href="agancy.php"><img src="images/index_12.jpg" alt="" width="157" height="28" border="0"></a></td>
		<td>
			<img src="images/index_13.jpg" width="11" height="28" alt=""></td>
		<td colspan="2"><a href="index.php"><img src="images/index_14.jpg" alt="" width="135" height="28" border="0"></a></td>
		<td colspan="2">
			<img src="images/index_15.jpg" width="32" height="28" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="images/empty_16.jpg" width="19" height="14" alt=""></td>
		<td colspan="14">
		  <img src="images/empty_17.jpg" width="912" height="14" alt=""></td>
		<td>
			<img src="images/empty_18.jpg" width="18" height="14" alt=""></td>
	</tr>
	<tr>
		<td colspan="16" width="949" background="images/cell_bg.jpg" valign="top"><table width="100%" height="100%"  >
       	  <tr>
            	<td width="4%">&nbsp;
                
                </td>
                
                
                <td width="92%" valign="top" align="right" dir="ltr"><table id="Table_2" width="862" height="394" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                      <td colspan="2"><img src="images/conhtml_01.jpg" width="862" height="37" alt=""></td>
                  </tr>
                    <tr>
                      <td colspan="2"><img src="images/conhtml_02.jpg" width="862" height="18" alt=""></td>
                    </tr>
                    <tr>
                      <td colspan="2"><img src="images/conhtml_03.jpg" width="862" height="77" alt=""></td>
                    </tr>
                    <tr>
                      <td colspan="2"><img src="images/conhtml_04.jpg" width="862" height="18" alt=""></td>
                    </tr>
                    <tr>
                      <td colspan="2"><img src="images/conhtml_05.jpg" width="862" height="57" alt=""></td>
                    </tr>
                    <tr>
                      <td colspan="2"><img src="images/conhtml_06.jpg" width="862" height="16" alt=""></td>
                    </tr>
                    <tr>
                      <td><img src="images/conhtml_07.jpg" width="587" height="63" alt=""></td>
                      <td><img src="images/conhtml_08.jpg" width="275" height="63" alt=""></td>
                    </tr>
                    <tr>
                      <td colspan="2"><img src="images/conhtml_09.jpg" width="862" height="27" alt=""></td>
                    </tr>
                    <tr>
                      <td><img src="images/conhtml_10.jpg" width="587" height="81" alt=""></td>
                      <td><img src="images/conhtml_11.jpg" width="275" height="81" alt=""></td>
                    </tr>
                  </table>
                  <table id="Table_" width="860" height="377" border="0" cellpadding="0" cellspacing="0">
                <form action="" method="post">
                  <tr>
                    <td colspan="12"><img src="images/on_01.jpg" width="859" height="25" alt=""></td>
                    <td><img src="images/spacer.gif" width="1" height="25" alt=""></td>
                  </tr>
                  <tr>
                    <td rowspan="13"><img src="images/on_02.jpg" width="26" height="328" alt=""></td>
                    <td colspan="3" rowspan="3"><img src="images/on_03.jpg" width="85" height="35" alt=""></td>
                    <td rowspan="3"><img src="images/on_04.jpg" width="13" height="35" alt=""></td>
                    <td><img src="images/on_05.jpg" width="226" height="8" alt=""></td>
                    <td rowspan="8"><img src="images/on_06.jpg" width="13" height="81" alt=""></td>
                    <td rowspan="4"><img src="images/on_07.jpg" width="126" height="42" alt=""></td>
                    <td><img src="images/on_08.jpg" width="227" height="8" alt=""></td>
                    <td colspan="2" rowspan="8"><img src="images/on_09.jpg" width="115" height="81" alt=""></td>
                    <td rowspan="13"><img src="images/on_10.jpg" width="28" height="328" alt=""></td>
                    <td><img src="images/spacer.gif" width="1" height="8" alt=""></td>
                  </tr>
                  <tr>
                    <td rowspan="2" background="images/on_11.jpg" width="226" height="27" align="right"><input type="text" name="on_phone" size="30"  dir="rtl" style="border: transparent ; background: transparent" tabindex="2"></td>
                    <td  width="227" height="26" background="images/on_12.jpg" align="right"><input type="text" name="on_name" size="30" dir="rtl" style="border: transparent ; background: transparent" tabindex="1"></td>
                    <td><img src="images/spacer.gif" width="1" height="26" alt=""></td>
                  </tr>
                  <tr>
                    <td rowspan="3"><img src="images/on_13.jpg" width="227" height="12" alt=""></td>
                    <td><img src="images/spacer.gif" width="1" height="1" alt=""></td>
                  </tr>
                  <tr>
                    <td colspan="5"><img src="images/on_14.jpg" width="324" height="7" alt=""></td>
                    <td><img src="images/spacer.gif" width="1" height="7" alt=""></td>
                  </tr>
                  <tr>
                    <td colspan="5" rowspan="3" background="images/on_15.jpg" width="324" height="38" align="right" >&nbsp;</td>
                    <td rowspan="4"><img src="images/online_16.jpg" width="126" height="39" alt=""></td>
                    <td><img src="images/spacer.gif" width="1" height="4" alt=""></td>
                  </tr>
                  <tr>
                    <td width="227" height="25" background="images/on_17.jpg" align="right"><input type="text" name="on_email" size="30" dir="rtl" style="border: transparent ; background: transparent" tabindex="3"></td>
                    <td><img src="images/spacer.gif" width="1" height="25" alt=""></td>
                  </tr>
                  <tr>
                    <td rowspan="2"><img src="images/on_18.jpg" width="227" height="10" alt=""></td>
                    <td><img src="images/spacer.gif" width="1" height="9" alt=""></td>
                  </tr>
                  <tr>
                    <td colspan="3"><img src="images/on_19.jpg" width="85" height="1" alt=""></td>
                    <td><img src="images/on_20.jpg" width="13" height="1" alt=""></td>
                    <td><img src="images/on_21.jpg" width="226" height="1" alt=""></td>
                    <td><img src="images/spacer.gif" width="1" height="1" alt=""></td>
                  </tr>
                  <tr>
                    <td colspan="10"><img src="images/online_22.jpg" width="805" height="33" alt=""></td>
                    <td><img src="images/spacer.gif" width="1" height="33" alt=""></td>
                  </tr>
                  <tr>
                    <td colspan="10"><img src="images/on_23.jpg" width="805" height="19" alt=""></td>
                    <td><img src="images/spacer.gif" width="1" height="19" alt=""></td>
                  </tr>
                  <tr>
                    <td><img src="images/on_24.jpg" width="15" height="147" alt=""></td>
                    <td colspan="8" background="images/on_25.jpg" width="774" height="147">
                    <p align="center">
					<textarea name="on_comment" id="on_comment" cols="92" rows="8" tabindex="5"  dir="rtl" style="border: transparent ; background: transparent"></textarea></td>
                
                    <td><img src="images/on_26.jpg" width="16" height="147" alt=""></td>
                    <td><img src="images/spacer.gif" width="1" height="147" alt=""></td>
                  </tr>
                  <tr>
                    <td colspan="10"><img src="images/on_27.jpg" width="805" height="16" alt=""></td>
                    <td><img src="images/spacer.gif" width="1" height="16" alt=""></td>
                  </tr>
                  <tr>
                    <td colspan="2"  width="64" height="32"><input type="image" src="images/on_28.jpg"
 		value="About submit buttons"
 		alt="[Submit]"
 		name="submit" ></td>
                    <td colspan="8"><img src="images/on_29.jpg" width="741" height="32" alt=""></td>
                    <td><img src="images/spacer.gif" width="1" height="32" alt=""></td>
                  </tr>
                  <tr>
                    <td colspan="12"><img src="images/on_30.jpg" width="859" height="23" alt=""></td>
                    <td><img src="images/spacer.gif" width="1" height="23" alt=""></td>
                  </tr>
                  <tr>
                    <td><img src="images/spacer.gif" width="26" height="1" alt=""></td>
                    <td><img src="images/spacer.gif" width="15" height="1" alt=""></td>
                    <td><img src="images/spacer.gif" width="49" height="1" alt=""></td>
                    <td><img src="images/spacer.gif" width="21" height="1" alt=""></td>
                    <td><img src="images/spacer.gif" width="13" height="1" alt=""></td>
                    <td><img src="images/spacer.gif" width="226" height="1" alt=""></td>
                    <td><img src="images/spacer.gif" width="13" height="1" alt=""></td>
                    <td><img src="images/spacer.gif" width="126" height="1" alt=""></td>
                    <td><img src="images/spacer.gif" width="227" height="1" alt=""></td>
                    <td><img src="images/spacer.gif" width="99" height="1" alt=""></td>
                    <td><img src="images/spacer.gif" width="16" height="1" alt=""></td>
                    <td><img src="images/spacer.gif" width="28" height="1" alt=""></td>
                    <td></td>
                  </tr>
                </form>
            </table></td>
                
                
                
              <td width="4%">&nbsp;
                
            </td>
            </tr>
        </table>
        </td>
	</tr>
	<tr>
		<td colspan="4">
			<img src="images/index_48.jpg" width="268" height="33" alt=""></td>
		<td colspan="2">
			<img src="images/index_49.jpg" width="170" height="33" alt=""></td>
		<td colspan="10">
			<img src="images/index_50.jpg" width="511" height="33" alt=""></td>
	</tr>
	<tr>
		<td colspan="16">
			<img src="images/index_51.jpg" width="949" height="21" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="images/spacer.gif" width="19" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="4" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="106" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="139" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="12" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="158" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="9" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="11" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="145" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="11" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="157" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="11" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="104" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="31" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="14" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="18" height="1" alt=""></td>
	</tr>
</table>
<!-- End Save for Web Slices -->
</body>
</html>